package com.dev.vo;

public class Member {
	private String name;
	private String id;
	private String pwd;
	private String birth;
	private String location;
	private String theater;
	private String movie;
	private String date;
	private String time;
	private String seat;
	
	public String getName() {
		return name;
	}
	public void setName(String tName) {
		this.name = tName;
	}
	public String getId() {
		return id;
	}
	public void setId(String tId) {
		this.id = tId;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String tPwd) {
		this.pwd = tPwd;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String tBirth) {
		this.birth = tBirth;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String tLocation) {
		this.location = tLocation;
	}
	public String getTheater() {
		return theater;
	}
	public void setTheater(String tTheater) {
		this.theater = tTheater;
	}
	public String getMovie() {
		return movie;
	}
	public void setMovie(String tMovie) {
		this.movie = tMovie;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String tDate) {
		this.date = tDate;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String tTime) {
		this.time = tTime;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String tSeat) {
		this.seat = tSeat;
	}
}
